-- Miniboss ROOM shuffle (2026-08-16 user ruling). Minibosses no longer shuffle as enemies -- see
-- EnemySanity.substitute_encounter, which skips every "MiniBoss*" encounter outright -- because
-- classifying by check NAME cannot express "this spawn is the room's miniboss", and both
-- directions broke live (ordinary trash drawing real minibosses out of the miniboss pool; the
-- room's own miniboss being replaced by a regular enemy).
--
-- Instead the ROOMS move. You still fight each miniboss in the room it belongs to, with its own
-- authored composition intact -- you might just meet Charybdis' room partway through Erebus.
--
-- The permutation is decided at GENERATION (Locations.compute_miniboss_room_map) and arrives in
-- the "miniboss_room_map" setting as "Host:Dest,...". It has to come from there rather than being
-- rolled here, because AP logic is derived from it: a miniboss check is reachable in whatever zone
-- hosts its room, exactly the correctness rule established for the enemy shuffle in
-- [[project_enemysanity_logic_follows_shuffle]]. A locally-invented permutation would describe
-- spawns the rules never saw.
MinibossRooms = MinibossRooms or {}

-- Mirrors Python Locations.MINIBOSS_ROOMS (hand-duplicated -- keep both in sync). Room -> the
-- biome letter it natively lives in. The biome letter doubles as the RoomSetName the run routes
-- by, and as the art package name ("BiomeF"), so one table serves both jobs.
-- Derivation of which miniboss each room holds is recorded Python-side; the mod only needs to
-- know where each room natively belongs.
MinibossRooms.ROOM_BIOME = {
  F_MiniBoss01 = "F", F_MiniBoss02 = "F", F_MiniBoss03 = "F",
  G_MiniBoss01 = "G", G_MiniBoss02 = "G", G_MiniBoss03 = "G",
  H_MiniBoss01 = "H", H_MiniBoss02 = "H",
  I_MiniBoss01 = "I", I_MiniBoss02 = "I",
  N_MiniBoss01 = "N", N_MiniBoss02 = "N",
  O_MiniBoss01 = "O", O_MiniBoss02 = "O",
  P_MiniBoss01 = "P", P_MiniBoss02 = "P",
  Q_MiniBoss02 = "Q", Q_MiniBoss03 = "Q", Q_MiniBoss04 = "Q", Q_MiniBoss05 = "Q",
}

-- The AP checks these rooms own, mirroring Python Locations.MINIBOSS_ROOM_CHECK_NAMES. Read by
-- EnemySanity.replacement_unit_id to keep them out of enemy substitution: each check must have
-- exactly one system deciding where it is obtainable, and these belong to the room shuffle.
-- "Shadow-Spiller" is the one that looks out of place -- it is F_MiniBoss02's miniboss
-- (FogEmitter_Elite), not ordinary trash; plain FogEmitter is in no generic spawn pool.
MinibossRooms.ROOM_CHECK_NAMES = {
  ["Root-Stalker"] = true, ["Shadow-Spiller"] = true, ["Master-Slicer"] = true,
  ["Deep Serpent"] = true, ["King Vermin"] = true, ["Hellifish"] = true,
  ["Phantom"] = true, ["Queen Lamia"] = true,
  ["The Verminancer"] = true, ["Goldwrath"] = true,
  ["Satyr Champion"] = true, ["Erymanthian Boar"] = true,
  ["Charybdis"] = true, ["The Yargonaut"] = true,
  ["Talos"] = true, ["Mega-Dracon"] = true,
  ["Spawn of Typhon"] = true, ["Tail of Typhon"] = true, ["Eye of Typhon"] = true,
  ["Twins of Typhon"] = true,
}

-- Lazily parsed from the "miniboss_room_map" setting, re-parsed only when the raw string actually
-- changes (e.g. reconnecting to a different seed). Same shape and lifecycle as EnemySanity's
-- shuffle_map cache.
local _raw = nil
local _map = {}

local function room_map()
  local raw = ItemManager.settings and ItemManager.settings["miniboss_room_map"]
  if raw ~= _raw then
    _raw = raw
    _map = {}
    if type(raw) == "string" and raw ~= "" then
      for pair in raw:gmatch("[^,]+") do
        local host, dest = pair:match("^(.-):(.*)$")
        if host and dest and host ~= "" and dest ~= "" then _map[host] = dest end
      end
    end
  end
  return _map
end

-- Public: is this room one the shuffle can move? (Used by the reload.lua hook to stay cheap on
-- the overwhelming majority of rooms, which aren't miniboss rooms at all.)
function MinibossRooms.is_miniboss_room(name)
  return type(name) == "string" and MinibossRooms.ROOM_BIOME[name] ~= nil
end

-- Make the destination room's art resident before it loads. Room art ships in the biome packages
-- exactly like enemy art does -- Content/Packages/1080p has BiomeF/G/H/I/N/O/P/Q .pkg files and no
-- per-room ones -- so a foreign miniboss room needs its own biome package or it renders untextured
-- (the same failure that produced the flat-black enemies, but for a whole arena).
local function preload_biome(letter)
  if type(letter) ~= "string" or letter == "" then return end
  if type(LoadPackages) ~= "function" then return end
  pcall(LoadPackages, { Name = "Biome" .. letter, IgnoreAssert = true })
end

-- Public: given the room the run just chose, return the room it should load instead (or nil to
-- leave it alone).
--
-- The swapped-in room is a DEEP COPY -- game.RoomData entries are shared authored templates, and
-- stamping our routing fields onto the global would leak into every later use of that room,
-- including its native appearance in its own biome.
--
-- Three fields carry the "foreign arena, native routing" behaviour the user asked for:
--   * ForceNextRoomSet -- the game's OWN override, read by ChooseNextRoomData (RunLogic.lua:789)
--     ahead of the current room's RoomSetName. Setting it to the HOST biome means that when you
--     take the exit out of Charybdis' room, the next room is drawn from Erebus as normal, so the
--     run's length and shape are unchanged ("continue the run forward").
--   * RoomSetName -- also set to the host biome (see below).
--   * AP_HostRoomSet -- ours, read by Routes.current(). Without it every AP system keyed off the
--     route (room checks, score, enemy checks, Dream scaling) would think you had teleported to
--     the Surface for one room, because those all resolve through the room's native RoomSetName.
function MinibossRooms.swap_for(roomData)
  local hostName = roomData and roomData.Name
  if not MinibossRooms.is_miniboss_room(hostName) then return nil end
  local destName = room_map()[hostName]
  if not destName or destName == hostName then return nil end
  local template = game.RoomData and game.RoomData[destName]
  if not template then
    rom.log.warning("[AP] miniboss rooms: no RoomData for '" .. tostring(destName)
      .. "' -- leaving " .. tostring(hostName) .. " alone")
    return nil
  end

  local hostBiome = MinibossRooms.ROOM_BIOME[hostName]
  local destBiome = MinibossRooms.ROOM_BIOME[destName]
  preload_biome(destBiome)

  local swapped = DeepCopyTable(template)
  swapped.ForceNextRoomSet = hostBiome
  swapped.AP_HostRoomSet = hostBiome
  -- Also the room's own RoomSetName: a Chaos gate out of this arena (G/N/O/Q arenas allow them)
  -- resolves "the previous room's biome" through it (vanilla ChooseNextRoomData's
  -- UsePreviousRoomSet branch), which would otherwise send the run into the foreign route.
  swapped.RoomSetName = hostBiome
  swapped.AP_MinibossRoomOrigin = hostName
  rom.log.info("[AP] miniboss rooms: " .. hostName .. " -> " .. destName
    .. " (routing stays in biome " .. tostring(hostBiome) .. ")")
  return swapped
end
