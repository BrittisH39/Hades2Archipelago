# Hades 2 Rogue Archipelago

Archipelago multiworld integration for Hades 2 Rogue. Mod was created with AI assistance (Tag is missing for Hades 2, will add the tag when it becomes available)



This mod connects to the Archipelago Hades 2 Rogue client. MAKE SURE you connect to the server before launching into a NEW save.



## Notes

* Ensure you've connected to the server via the Hades 2 Rogue client before you launch into a save.
* Make sure that the save is a new save
* Zagreus Journey is no longer a dependency, so it won't be downloaded automatically. If you want the Hades 1 content, download "Zagreus Journey" by NikkelM on the same profile. It only works if you have Hades 1 installed.
* This is not completely stable yet and expect to run into bugs. Feel free to inform me of those bugs on the Archipelago Discord: https://discord.gg/8Z65BR2.
* Hades 2 Rogue thread once you're in the Archipelago discord: https://discord.com/channels/731205301247803413/1521929337954238624

